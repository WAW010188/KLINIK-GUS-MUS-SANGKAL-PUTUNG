from django.apps import AppConfig


class ApotekerConfig(AppConfig):
    name = 'apoteker'
