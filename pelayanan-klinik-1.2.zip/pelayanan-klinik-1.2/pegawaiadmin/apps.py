from django.apps import AppConfig


class PegawaiadminConfig(AppConfig):
    name = 'pegawaiadmin'
