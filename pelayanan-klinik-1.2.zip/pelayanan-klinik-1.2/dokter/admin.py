from django.contrib import admin
from dokter.models import RekamMedis
# Register your models here.
admin.site.register(RekamMedis)
