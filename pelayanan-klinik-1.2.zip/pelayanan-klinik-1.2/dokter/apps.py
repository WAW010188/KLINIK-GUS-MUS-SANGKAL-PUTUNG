from django.apps import AppConfig


class DokterConfig(AppConfig):
    name = 'dokter'
