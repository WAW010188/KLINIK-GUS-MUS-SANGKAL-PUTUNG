from django.apps import AppConfig


class PasienConfig(AppConfig):
    name = 'pasien'
