from django.contrib import admin
from pasien.models import Pasien
# Register your models here.
admin.site.register(Pasien)
